export default function Home() {
  return (
    <main className='min-h-screen flex flex-col items-center justify-center text-center p-6'>
      <h1 className='text-4xl font-bold mb-3'>RocketshipCryptoWalletRecovery</h1>
      <p className='text-gray-700 max-w-xl'>
        Recover lost wallets and manage crypto investments securely.
      </p>
      <p className='mt-6 text-sm'>
        Support: <a href='mailto:support@rocketshipcryptowalletrecovery.com' className='text-blue-600 underline'>
          support@rocketshipcryptowalletrecovery.com
        </a>
      </p>
    </main>
  )
}
