# Infra Notes

Run `docker-compose up -d` to start PostgreSQL locally.
Access DB via `psql postgres://rocketship:rocketship@localhost:5432/rocketship_db`.
